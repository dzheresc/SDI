#pragma once

#include <string>
#include <vector>
#include <unordered_map>
#include <cstdint>
#include <memory>
#include <cstring>
#include <stdexcept>

class StringCache14;

/**
 * StringView - A simplified replica of std::string_view for C++14.
 * Non-owning view into a string buffer.
 */
class StringView {
public:
    StringView() noexcept : data_(nullptr), size_(0) {}

    StringView(const char* str) noexcept
        : data_(str), size_(str ? std::strlen(str) : 0) {}

    StringView(const char* str, size_t len) noexcept
        : data_(str), size_(len) {}

    StringView(const std::string& str) noexcept
        : data_(str.data()), size_(str.size()) {}

    // Accessors
    const char* data() const noexcept { return data_; }
    size_t size() const noexcept { return size_; }
    size_t length() const noexcept { return size_; }
    bool empty() const noexcept { return size_ == 0; }

    // Element access
    const char& operator[](size_t pos) const noexcept {
        return data_[pos];
    }

    const char& at(size_t pos) const {
        if (pos >= size_) {
            throw std::out_of_range("StringView::at");
        }
        return data_[pos];
    }

    // Iterators
    const char* begin() const noexcept { return data_; }
    const char* end() const noexcept { return data_ + size_; }

    // Comparison
    bool operator==(const StringView& other) const noexcept {
        if (size_ != other.size_) return false;
        return std::memcmp(data_, other.data_, size_) == 0;
    }

    bool operator!=(const StringView& other) const noexcept {
        return !(*this == other);
    }

    // Conversion
    std::string to_string() const {
        return std::string(data_, size_);
    }

private:
    const char* data_;
    size_t size_;
};

/**
 * FastStringHash - Optimized hash function for short strings (4-20 bytes).
 * Uses FNV-1a algorithm which is very fast for small strings commonly found in JSON.
 */
struct FastStringHash {
    size_t operator()(const StringView& sv) const noexcept {
        // FNV-1a hash - optimized for short strings
        size_t hash = 14695981039346656037ULL; // FNV offset basis
        const unsigned char* data = reinterpret_cast<const unsigned char*>(sv.data());
        const unsigned char* end = data + sv.size();

        while (data < end) {
            hash ^= *data++;
            hash *= 1099511628211ULL; // FNV prime
        }

        return hash;
    }
};

/**
 * StringViewEqual - Equality comparator for StringView in hash maps.
 */
struct StringViewEqual {
    bool operator()(const StringView& a, const StringView& b) const noexcept {
        return a == b;
    }
};

/**
 * CachedString14 - A lightweight reference to a string in the cache.
 * Acts as a numeric ID that can be resolved to a StringView.
 */
class CachedString14 {
public:
    CachedString14() : index_(INVALID_INDEX) {}

    explicit CachedString14(size_t index) : index_(index) {}

    bool is_valid() const { return index_ != INVALID_INDEX; }

    size_t index() const { return index_; }

    bool operator==(const CachedString14& other) const {
        return index_ == other.index_;
    }

    bool operator!=(const CachedString14& other) const {
        return index_ != other.index_;
    }

private:
    static constexpr size_t INVALID_INDEX = static_cast<size_t>(-1);
    size_t index_;
};

/**
 * StringCache14 - Manages a pool of unique strings.
 * Optimized for fast access via index-based lookup.
 * C++14 compatible version using custom StringView.
 */
class StringCache14 {
public:
    static StringCache14& instance() {
        thread_local StringCache14 ctx;
        return ctx;
    }

    StringCache14() : used_(0) {
        allocate_new_block(BLOCK_SIZE);
        // Pre-allocate to avoid rehashing during typical JSON parsing
        reserve(8192);
        intern("");
    }

    // Prevent copying (cache should be unique)
    StringCache14(const StringCache14&) = delete;
    StringCache14& operator=(const StringCache14&) = delete;

    // Prevent moving (singleton should not be moved)
    StringCache14(StringCache14&&) = delete;
    StringCache14& operator=(StringCache14&&) = delete;

    /**
     * Add a string to the cache or get existing reference.
     * Returns a CachedString14 that references the string.
     */
    CachedString14 intern(StringView str) {
        // Check if string already exists
        auto it = lookup_.find(str);
        if (it != lookup_.end()) {
            return CachedString14(it->second);
        }

        // assure enough space in current block
        auto len = str.size();
        if (len > BLOCK_SIZE) {
            allocate_new_block(len); // Allocate a dedicated block for large strings
        } else if ((used_ + len) > BLOCK_SIZE) {
            allocate_new_block(BLOCK_SIZE);
        }

        auto* dest = blocks_.back().get() + used_;
        std::memcpy(dest, str.data(), len);

        used_ += len;
        //used_ = (used_ + 15) & ~15; // Align to 16 bytes
        used_ = (used_ + 3) & ~3; // Align to 4 bytes, cache density optimization

        StringView stored(dest, len); // Create StringView pointing to stored string
        size_t index = index_.size();
        index_.push_back(stored);
        // Update lookup map with StringView pointing to the stored string
        lookup_.emplace(stored, index);

        return CachedString14(index);
    }

    /**
     * Convenience method for interning from raw pointer and length.
     * Useful for JSON parsers working directly with char buffers.
     */
    CachedString14 intern(const char* data, size_t len) {
        return intern(StringView(data, len));
    }

    /**
     * Convenience method for interning from std::string.
     */
    CachedString14 intern(const std::string& str) {
        return intern(StringView(str));
    }

    /**
     * Resolve a CachedString14 to its StringView.
     * Returns empty StringView if CachedString14 is invalid or out of bounds.
     */
    StringView resolve(const CachedString14& cached) const {
        if (!cached.is_valid() || cached.index() >= index_.size()) {
            return index_[0]; // Return empty StringView for invalid references
        }
        return index_[cached.index()];
    }

    /**
     * Get the number of unique strings cached.
     */
    size_t size() const {
        return index_.size();
    }

    /**
     * Clear all cached strings.
     */
    void clear() {
        index_.clear();
        lookup_.clear();
        blocks_.clear();
        reserve(8192);
        allocate_new_block(BLOCK_SIZE);
        intern("");
    }

    /**
     * Reserve space for expected number of unique strings.
     */
    void reserve(size_t capacity) {
        index_.reserve(capacity);
        lookup_.reserve(capacity);
    }

private:
    static const size_t BLOCK_SIZE = 64 * 1024;

    void allocate_new_block(size_t size) {
        blocks_.emplace_back(std::unique_ptr<char[]>(new char[size]));
        used_ = 0;
    }

    size_t used_;

    // Storage for unique strings (fast O(1) access by index)
    std::vector<StringView> index_;
    // Map from string content to index (fast O(1) lookup for deduplication)
    // Uses FastStringHash optimized for short strings common in JSON
    std::unordered_map<StringView, size_t, FastStringHash, StringViewEqual> lookup_;
    // Actual string data is stored here. StringViews in lookup_ and index_ point to some place within blocks_
    std::vector<std::unique_ptr<char[]>> blocks_;
};

namespace std {
    template<>
    struct hash<CachedString14> {
        size_t operator()(const CachedString14& cached) const {
            return std::hash<size_t>()(cached.index());
        }
    };
}
