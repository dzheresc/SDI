#include "string_cache_14.h"
#include <iostream>
#include <chrono>
#include <iomanip>
#include <vector>

using namespace std::chrono;

// Helper function to measure execution time
template<typename Func>
double measure_ns(Func&& func, int iterations) {
    auto start = high_resolution_clock::now();
    for (int i = 0; i < iterations; i++) {
        func();
    }
    auto end = high_resolution_clock::now();
    auto duration = duration_cast<nanoseconds>(end - start).count();
    return static_cast<double>(duration) / iterations;
}

int main() {
    std::cout << "StringCache14 Performance Benchmark (C++14)\n";
    std::cout << "==========================================\n\n";

    StringCache14& cache = StringCache14::instance();

    // Benchmark 1: Repeated string interning (hot path - duplicate lookups)
    std::cout << "1. Hot Path - Duplicate String Lookups:\n";
    {
        // Pre-intern the string
        cache.intern("firstName");

        auto time = measure_ns([&cache]() {
            cache.intern("firstName");
        }, 1000000);

        std::cout << "   Average time per intern (duplicate): "
                  << std::fixed << std::setprecision(2) << time << " ns\n";
    }

    // Benchmark 2: New string interning (cold path)
    std::cout << "\n2. Cold Path - New String Insertion:\n";
    {
        std::vector<std::string> test_strings;
        for (int i = 0; i < 10000; i++) {
            test_strings.push_back("test_string_" + std::to_string(i));
        }

        auto time = measure_ns([&cache, &test_strings]() {
            static int idx = 0;
            cache.intern(test_strings[idx++ % test_strings.size()]);
        }, 10000);

        std::cout << "   Average time per intern (new string): "
                  << std::fixed << std::setprecision(2) << time << " ns\n";
    }

    // Benchmark 3: JSON-like workload (typical keys)
    std::cout << "\n3. JSON-like Workload (Typical Keys):\n";
    {
        std::vector<std::string> json_keys = {
            "id", "name", "email", "firstName", "lastName",
            "address", "city", "state", "zip", "country",
            "phone", "mobile", "fax", "website", "company"
        };

        // Simulate JSON parsing: each key appears many times
        auto time = measure_ns([&cache, &json_keys]() {
            static int idx = 0;
            cache.intern(json_keys[idx++ % json_keys.size()]);
        }, 1000000);

        std::cout << "   Average time per intern (JSON keys): "
                  << std::fixed << std::setprecision(2) << time << " ns\n";
        std::cout << "   Total unique keys cached: " << cache.size() << "\n";
    }

    // Benchmark 4: String resolution (CachedString14 -> StringView)
    std::cout << "\n4. String Resolution:\n";
    {
        auto cached = cache.intern("testString");

        auto time = measure_ns([&cache, cached]() {
            volatile auto sv = cache.resolve(cached);
            (void)sv; // Prevent optimization
        }, 1000000);

        std::cout << "   Average time per resolve: "
                  << std::fixed << std::setprecision(2) << time << " ns\n";
    }

    // Benchmark 5: Mixed workload (80% duplicates, 20% new strings)
    std::cout << "\n5. Mixed Workload (80% duplicates, 20% new):\n";
    {
        StringCache14 test_cache; // Fresh cache for this test

        std::vector<std::string> common_strings = {
            "status", "success", "error", "message", "data"
        };

        std::vector<std::string> varied_strings;
        for (int i = 0; i < 1000; i++) {
            varied_strings.push_back("unique_" + std::to_string(i));
        }

        auto time = measure_ns([&test_cache, &common_strings, &varied_strings]() {
            static int counter = 0;
            if (counter % 5 < 4) {
                // 80% - intern common string
                test_cache.intern(common_strings[counter % common_strings.size()]);
            } else {
                // 20% - intern new string
                test_cache.intern(varied_strings[counter % varied_strings.size()]);
            }
            counter++;
        }, 50000);

        std::cout << "   Average time per intern (mixed): "
                  << std::fixed << std::setprecision(2) << time << " ns\n";
        std::cout << "   Unique strings cached: " << test_cache.size() << "\n";
    }

    // Benchmark 6: Cache locality test (sequential access)
    std::cout << "\n6. Cache Locality Test:\n";
    {
        StringCache14 test_cache;
        std::vector<CachedString14> cached_strings;

        // Intern many strings
        for (int i = 0; i < 10000; i++) {
            cached_strings.push_back(test_cache.intern("string_" + std::to_string(i)));
        }

        // Sequential resolve
        auto start = high_resolution_clock::now();
        volatile size_t total_len = 0;
        for (const auto& cs : cached_strings) {
            total_len += test_cache.resolve(cs).size();
        }
        auto end = high_resolution_clock::now();
        auto duration = duration_cast<nanoseconds>(end - start).count();

        std::cout << "   Time to resolve 10,000 strings sequentially: "
                  << duration / 1000.0 << " μs\n";
        std::cout << "   Average time per resolve: "
                  << static_cast<double>(duration) / cached_strings.size() << " ns\n";
    }

    // Benchmark 7: StringView operations
    std::cout << "\n7. StringView Performance:\n";
    {
        const char* test_data = "Hello, World! This is a test string.";
        StringView sv1(test_data);
        StringView sv2(test_data);

        // Equality comparison
        auto time = measure_ns([&sv1, &sv2]() {
            volatile bool result = (sv1 == sv2);
            (void)result;
        }, 1000000);

        std::cout << "   Average time per StringView comparison: "
                  << std::fixed << std::setprecision(2) << time << " ns\n";

        // Hash computation
        FastStringHash hasher;
        auto hash_time = measure_ns([&hasher, &sv1]() {
            volatile size_t h = hasher(sv1);
            (void)h;
        }, 1000000);

        std::cout << "   Average time per StringView hash: "
                  << std::fixed << std::setprecision(2) << hash_time << " ns\n";
    }

    // Memory usage estimation
    std::cout << "\n8. Memory Usage Estimation:\n";
    std::cout << "   Unique strings in cache: " << cache.size() << "\n";
    std::cout << "   StringView size: " << sizeof(StringView) << " bytes\n";
    std::cout << "   Index memory (approx): "
              << (cache.size() * sizeof(StringView)) / 1024 << " KB\n";
    std::cout << "   CachedString14 size: " << sizeof(CachedString14) << " bytes\n";

    std::cout << "\n==========================================\n";
    std::cout << "Benchmark Complete!\n";

    return 0;
}
