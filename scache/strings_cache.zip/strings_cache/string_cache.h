#pragma once

#include <string>
#include <string_view>
#include <vector>
#include <unordered_map>
#include <cstdint>
#include <memory>
#include <cstring>

class StringCache;

/**
 * FastStringHash - Optimized hash function for short strings (4-20 bytes).
 * Uses FNV-1a algorithm which is very fast for small strings commonly found in JSON.
 */
struct FastStringHash {
    size_t operator()(std::string_view sv) const noexcept {
        // FNV-1a hash - optimized for short strings
        size_t hash = 14695981039346656037ULL; // FNV offset basis
        const unsigned char* data = reinterpret_cast<const unsigned char*>(sv.data());
        const unsigned char* end = data + sv.size();

        while (data < end) {
            hash ^= *data++;
            hash *= 1099511628211ULL; // FNV prime
        }

        return hash;
    }
};

/**
 * CachedString - A lightweight reference to a string in the cache.
 * Acts as a numeric ID that can be resolved to a string_view.
 */
class CachedString {
public:
    CachedString() : index_(INVALID_INDEX) {}

    explicit CachedString(size_t index) : index_(index) {}

    bool is_valid() const { return index_ != INVALID_INDEX; }

    size_t index() const { return index_; }

    bool operator==(const CachedString& other) const {
        return index_ == other.index_;
    }

    bool operator!=(const CachedString& other) const {
        return index_ != other.index_;
    }

private:
    static constexpr size_t INVALID_INDEX = static_cast<size_t>(-1);
    size_t index_;
};

/**
 * StringCache - Manages a pool of unique strings.
 * Optimized for fast access via index-based lookup.
 */
class StringCache {
public:
    static StringCache& instance() {
        thread_local StringCache ctx;
        return ctx;
    }

    StringCache() : used_(0) {
        allocate_new_block(BLOCK_SIZE);
        // Pre-allocate to avoid rehashing during typical JSON parsing
        reserve(8192);
        intern("");
    }

    // Prevent copying (cache should be unique)
    StringCache(const StringCache&) = delete;
    StringCache& operator=(const StringCache&) = delete;

    // Prevent moving (singleton should not be moved)
    StringCache(StringCache&&) = delete;
    StringCache& operator=(StringCache&&) = delete;

    /**
     * Add a string to the cache or get existing reference.
     * Returns a CachedString that references the string.
     */
    CachedString intern(std::string_view str) {
        // Check if string already exists
        auto it = lookup_.find(str);
        if (it != lookup_.end()) {
            return CachedString(it->second);
        }

        // assure enough space in current block
        auto len = str.size();
        if (len > BLOCK_SIZE) {
            allocate_new_block(len); // Allocate a dedicated block for large strings
        } else if ((used_ + len) > BLOCK_SIZE) {
            allocate_new_block(BLOCK_SIZE);
        }

        auto* dest = blocks_.back().get() + used_;
        std::memcpy(dest, str.data(), len);

        used_ += len;
        //used_ = (used_ + 15) & ~15; // Align to 16 bytes
        used_ = (used_ + 3) & ~3; // Align to 4 bytes, cache density optimization

        std::string_view stored(dest, len); // Create string_view pointing to stored string
        size_t index = index_.size();
        index_.push_back(stored);
        // Update lookup map with string_view pointing to the stored string
        lookup_.emplace(stored, index);

        return CachedString(index);
    }

    /**
     * Convenience method for interning from raw pointer and length.
     * Useful for JSON parsers working directly with char buffers.
     */
    CachedString intern(const char* data, size_t len) {
        return intern(std::string_view(data, len));
    }

    /**
     * Resolve a CachedString to its string_view.
     * Returns empty string_view if CachedString is invalid or out of bounds.
     */
    std::string_view resolve(const CachedString& cached) const {
        if (!cached.is_valid() || cached.index() >= index_.size()) {
            return index_[0]; // Return empty string_view for invalid references
        }
        return index_[cached.index()];
    }

    /**
     * Get the number of unique strings cached.
     */
    size_t size() const {
        return index_.size();
    }

    /**
     * Clear all cached strings.
     */
    void clear() {
        index_.clear();
        lookup_.clear();
        blocks_.clear();
        reserve(8192);
        allocate_new_block(BLOCK_SIZE);
        intern("");
    }

    /**
     * Reserve space for expected number of unique strings.
     */
    void reserve(size_t capacity) {
        index_.reserve(capacity);
        lookup_.reserve(capacity);
    }

private:
    static const size_t BLOCK_SIZE = 64 * 1024;

    void allocate_new_block(size_t size) {
        blocks_.emplace_back(std::make_unique<char[]>(size));
        used_ = 0;
    }

    size_t used_;

    // Storage for unique strings (fast O(1) access by index)
    std::vector<std::string_view> index_;
    // Map from string content to index (fast O(1) lookup for deduplication)
    // Uses FastStringHash optimized for short strings common in JSON
    std::unordered_map<std::string_view, size_t, FastStringHash> lookup_;
    // Actual string data is stored here. string_views in lookup_ and index_ point to some place within blocks_
    std::vector<std::unique_ptr<char[]>> blocks_;
};

namespace std {
    template<>
    struct hash<CachedString> {
        size_t operator()(const CachedString& cached) const {
            return std::hash<size_t>()(cached.index());
        }
    };
}
