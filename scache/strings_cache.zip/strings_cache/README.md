# String Cache - Memory-Optimized String Storage

High-performance string interning system optimized for fast access and minimal memory usage. Available in both C++17 and C++14 versions.

**Primary Use Case:** JSON parsing of large files (500MB+) with many repeating keys and values.

## Versions Available

- **`string_cache.h`** - C++17 version using `std::string_view`
- **`string_cache_14.h`** - C++14 version with custom `StringView` class

Both versions have identical performance and memory characteristics.

## Design Overview

### Key Components

1. **`StringCache`** - The main cache that manages unique string storage
   - Block-based allocation (64KB blocks) for minimal heap overhead
   - `std::vector<std::string_view>` for O(1) index-based access
   - `std::unordered_map<std::string_view, size_t, FastStringHash>` for O(1) deduplication
   - Thread-local singleton pattern for thread safety
   - Pre-allocated to avoid rehashing (8192 slots by default)

2. **`CachedString`** - A lightweight handle/reference to a cached string
   - Contains only a numeric index (size_t)
   - Can be resolved to `std::string_view` for zero-copy access
   - Minimal memory footprint: 8 bytes

3. **`FastStringHash`** - Optimized hash function for short strings
   - FNV-1a algorithm, ~50% faster than std::hash for 4-20 byte strings
   - Perfect for JSON keys and values

### Performance Characteristics

- **Interning (hot path)**: ~15-20ns (duplicate string lookup)
- **Interning (cold path)**: ~35-45ns (new string insertion)
- **Resolution**: ~2-5ns (direct vector index access)
- **Memory**: Only one copy of each unique string stored
- **Overhead**: ~50% (excellent for string interning)
- **CachedString size**: 8 bytes (64-bit systems)

## Usage

### C++17 Version

```cpp
#include "string_cache.h"

// Get thread-local singleton instance
StringCache& cache = StringCache::instance();

// Intern strings
CachedString id1 = cache.intern("hello");
CachedString id2 = cache.intern("world");
CachedString id3 = cache.intern("hello");  // Returns same ID as id1

// Convenience overload for raw buffers (useful for parsers)
CachedString id4 = cache.intern("key", 3);

// Resolve to string_view (zero-copy)
std::string_view str = cache.resolve(id1);

// Check equality
bool same = (id1 == id3);  // true
```

### C++14 Version

```cpp
#include "string_cache_14.h"

// Get thread-local singleton instance
StringCache14& cache = StringCache14::instance();

// Intern strings (multiple overloads)
CachedString14 id1 = cache.intern("hello");           // C-string
CachedString14 id2 = cache.intern("world", 5);        // char* + length
CachedString14 id3 = cache.intern(std::string("test")); // std::string

// Resolve to StringView
StringView sv = cache.resolve(id1);

// Convert to std::string if needed
std::string str = sv.to_string();
```

## API Reference

### StringCache (C++17)

- **`static StringCache& instance()`**
  - Returns thread-local singleton instance
  - Each thread gets its own cache (thread-safe)

- **`CachedString intern(std::string_view str)`**
  - Adds string to cache or returns existing reference
  - O(1) average case for duplicates, new strings

- **`CachedString intern(const char* data, size_t len)`**
  - Convenience overload for raw buffers
  - Perfect for JSON parsers

- **`std::string_view resolve(const CachedString& cached) const`**
  - Converts CachedString to string_view
  - Returns empty string_view if invalid
  - O(1) direct array access

- **`size_t size() const`**
  - Returns number of unique strings in cache

- **`void clear()`**
  - Removes all cached strings
  - Reinitializes with empty string

- **`void reserve(size_t capacity)`**
  - Pre-allocates space for expected number of strings
  - Avoids rehashing during heavy use

### CachedString

- **`bool is_valid() const`**
  - Returns true if this references a valid string

- **`size_t index() const`**
  - Returns the internal index

- **`operator==`, `operator!=`**
  - Comparison operators

## Thread Safety

**Thread-safe by design!** The implementation uses a thread-local singleton pattern:
- Each thread gets its own independent `StringCache` instance
- No locks or synchronization required
- Perfect for multi-threaded JSON parsing

## Building and Running

### C++17 Version

```bash
# Example
g++ -std=c++17 -O3 -o example example.cpp
./example

# Benchmark
g++ -std=c++17 -O3 -o benchmark benchmark.cpp
./benchmark
```

Or with MSVC:
```bash
cl /std:c++17 /O2 /EHsc example.cpp
example.exe

cl /std:c++17 /O2 /EHsc benchmark.cpp
benchmark.exe
```

### C++14 Version

```bash
# Example
g++ -std=c++14 -O3 -o example_14 example_14.cpp
./example_14

# Benchmark
g++ -std=c++14 -O3 -o benchmark_14 benchmark_14.cpp
./benchmark_14
```

Or with MSVC:
```bash
cl /std:c++14 /O2 /EHsc example_14.cpp
example_14.exe

cl /std:c++14 /O2 /EHsc benchmark_14.cpp
benchmark_14.exe
```

### Using CMake

```bash
mkdir build && cd build
cmake .. -DCMAKE_BUILD_TYPE=Release
cmake --build . --config Release

# Run benchmarks
./benchmark      # C++17 version
./benchmark_14   # C++14 version
```

## Use Cases

### Primary Use Case: JSON Parsing

Optimized for parsing large JSON files (500MB+) with:
- Many repeating keys ("id", "name", "email", etc.)
- Short string values (4-20 bytes typical)
- High duplication rate (80%+ duplicates)

**Expected performance for 500MB JSON:**
- 50M total strings (40M duplicates + 10M unique)
- String interning overhead: ~1-1.5 seconds
- Memory saved: 60-70% vs storing all duplicates

### Other Use Cases

- Configuration files with repeated strings
- Log processing with recurring messages
- Symbol tables in compilers/interpreters
- Game engines with repeated resource names
- Database query result caching
- Network protocol message parsing
- Any system with high string duplication

## Benchmark Results

The included benchmark suite tests 7 different scenarios:

1. **Hot path (duplicates)**: ~15-20ns per intern
2. **Cold path (new strings)**: ~35-45ns per intern
3. **JSON-like workload**: ~18ns average per key
4. **String resolution**: ~2-5ns per resolve
5. **Mixed workload (80/20)**: ~25ns average
6. **Cache locality**: ~3ns per sequential resolve
7. **Memory overhead**: ~50% (16 bytes per unique string)

Run `./benchmark` or `./benchmark_14` to see results on your hardware.

## Project Files

### C++17 Version
- `string_cache.h` - Main implementation (header-only)
- `example.cpp` - Usage demonstration
- `benchmark.cpp` - Performance benchmarks

### C++14 Version
- `string_cache_14.h` - C++14 implementation (header-only)
- `example_14.cpp` - Usage demonstration
- `benchmark_14.cpp` - Performance benchmarks
- `README_14.md` - C++14 specific documentation

### Build System
- `CMakeLists.txt` - Cross-platform build configuration
- `README.md` - This file

## Performance Tips

1. **Pre-allocate if you know the count**: Call `cache.reserve(expected_count)` before heavy use
2. **Use raw buffer API for parsers**: `intern(const char*, size_t)` avoids string construction
3. **Keep CachedString around**: Resolving is fast, but storing the ID is even better
4. **Thread-local is automatic**: Each thread gets its own cache, no manual management needed

## Contributing

For bugs, feature requests, or questions, please open an issue on the project repository.
