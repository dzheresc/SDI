#!/bin/bash

# Build script for JSON handler examples
# Requires RapidJSON to be installed or available

set -e

# Configuration
CXX="${CXX:-g++}"
CXXFLAGS="-std=c++14 -O3 -Wall -Wextra"
RAPIDJSON_INCLUDE="${RAPIDJSON_INCLUDE:-/usr/include}"

# Check if RapidJSON is available
if [ ! -d "$RAPIDJSON_INCLUDE/rapidjson" ]; then
    echo "Warning: RapidJSON not found at $RAPIDJSON_INCLUDE/rapidjson"
    echo ""
    echo "To install RapidJSON:"
    echo "  Ubuntu/Debian: sudo apt-get install rapidjson-dev"
    echo "  macOS:         brew install rapidjson"
    echo "  Or download:   https://github.com/Tencent/rapidjson"
    echo ""
    echo "Set RAPIDJSON_INCLUDE to specify custom location:"
    echo "  export RAPIDJSON_INCLUDE=/path/to/rapidjson/include"
    echo ""
    read -p "Continue anyway? (y/n) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

echo "Building JSON examples with RapidJSON support..."
echo "CXX: $CXX"
echo "CXXFLAGS: $CXXFLAGS"
echo "RapidJSON include: $RAPIDJSON_INCLUDE"
echo ""

# Build json_example
echo "Building json_example..."
$CXX $CXXFLAGS -DRAPIDJSON_AVAILABLE \
    -I"$RAPIDJSON_INCLUDE" \
    -o json_example json_example.cpp

if [ $? -eq 0 ]; then
    echo "✓ json_example built successfully"
else
    echo "✗ Failed to build json_example"
    exit 1
fi

# Build json_benchmark
echo "Building json_benchmark..."
$CXX $CXXFLAGS -DRAPIDJSON_AVAILABLE \
    -I"$RAPIDJSON_INCLUDE" \
    -o json_benchmark json_benchmark.cpp

if [ $? -eq 0 ]; then
    echo "✓ json_benchmark built successfully"
else
    echo "✗ Failed to build json_benchmark"
    exit 1
fi

echo ""
echo "Build complete!"
echo ""
echo "Run examples:"
echo "  ./json_example"
echo "  ./json_benchmark"
echo ""
