#include "json_handler.h"
#include <iostream>
#include <iomanip>

// Note: This example requires RapidJSON to be installed
// Download from: https://github.com/Tencent/rapidjson
// Or install via: apt-get install rapidjson-dev / vcpkg install rapidjson

#ifdef RAPIDJSON_AVAILABLE
#include "rapidjson/reader.h"
#include "rapidjson/stringbuffer.h"
#include "rapidjson/writer.h"
#endif

void printJSONValue(const JSONValue& value, StringCache14& cache, int indent = 0) {
    std::string indentStr(indent * 2, ' ');

    switch (value.type()) {
        case JSONValue::TYPE_NULL:
            std::cout << "null";
            break;

        case JSONValue::TYPE_BOOL:
            std::cout << (value.getBool() ? "true" : "false");
            break;

        case JSONValue::TYPE_INT64:
            std::cout << value.getInt64();
            break;

        case JSONValue::TYPE_UINT64:
            std::cout << value.getUint64();
            break;

        case JSONValue::TYPE_DOUBLE:
            std::cout << std::fixed << std::setprecision(2) << value.getDouble();
            break;

        case JSONValue::TYPE_STRING:
            std::cout << "\"" << cache.resolve(value.getString()).to_string() << "\"";
            break;

        case JSONValue::TYPE_ARRAY:
            std::cout << "[\n";
            {
                const auto& arr = value.getArray();
                for (size_t i = 0; i < arr.size(); ++i) {
                    std::cout << indentStr << "  ";
                    printJSONValue(arr[i], cache, indent + 1);
                    if (i < arr.size() - 1) std::cout << ",";
                    std::cout << "\n";
                }
            }
            std::cout << indentStr << "]";
            break;

        case JSONValue::TYPE_OBJECT:
            std::cout << "{\n";
            {
                const auto& obj = value.getObject();
                for (size_t i = 0; i < obj.size(); ++i) {
                    std::cout << indentStr << "  \""
                              << cache.resolve(obj[i].first).to_string()
                              << "\": ";
                    printJSONValue(obj[i].second, cache, indent + 1);
                    if (i < obj.size() - 1) std::cout << ",";
                    std::cout << "\n";
                }
            }
            std::cout << indentStr << "}";
            break;
    }
}

int main() {
    std::cout << "JSON Handler with Cached Strings Example\n";
    std::cout << "=========================================\n\n";

#ifdef RAPIDJSON_AVAILABLE
    // Example JSON with repeated keys and values
    const char* json = R"({
        "users": [
            {
                "id": 1,
                "name": "John Doe",
                "email": "john@example.com",
                "active": true
            },
            {
                "id": 2,
                "name": "Jane Smith",
                "email": "jane@example.com",
                "active": true
            },
            {
                "id": 3,
                "name": "Bob Johnson",
                "email": "bob@example.com",
                "active": false
            }
        ],
        "metadata": {
            "version": "1.0",
            "timestamp": 1234567890,
            "count": 3
        }
    })";

    std::cout << "Parsing JSON with RapidJSON SAX parser...\n\n";

    // Create handler
    CachedStringHandler handler;

    // Parse using RapidJSON's SAX-style parser
    rapidjson::Reader reader;
    rapidjson::StringStream ss(json);

    if (reader.Parse(ss, handler)) {
        std::cout << "Parsing successful!\n\n";

        // Get the result
        JSONValue result = handler.getResult();

        std::cout << "Parsed JSON structure:\n";
        printJSONValue(result, StringCache14::instance());
        std::cout << "\n\n";

        std::cout << "Cache Statistics:\n";
        std::cout << "  Unique strings cached: " << handler.getCacheSize() << "\n";
        std::cout << "  Memory saved by caching repeated keys/values!\n\n";

        // Demonstrate memory efficiency
        std::cout << "Memory Efficiency:\n";
        std::cout << "  Without caching:\n";
        std::cout << "    - Key 'id' appears 3 times: 3 × 2 bytes = 6 bytes\n";
        std::cout << "    - Key 'name' appears 3 times: 3 × 4 bytes = 12 bytes\n";
        std::cout << "    - Key 'email' appears 3 times: 3 × 5 bytes = 15 bytes\n";
        std::cout << "    - Key 'active' appears 3 times: 3 × 6 bytes = 18 bytes\n";
        std::cout << "    Total for just these keys: 51 bytes\n\n";
        std::cout << "  With caching:\n";
        std::cout << "    - Each key stored once: (2+4+5+6) = 17 bytes\n";
        std::cout << "    - CachedString refs: 4 × 8 bytes × 3 = 96 bytes\n";
        std::cout << "    But CachedString refs are part of structure anyway!\n";
        std::cout << "    Actual savings: 51 - 17 = 34 bytes (66% saved)\n";

    } else {
        std::cout << "Parsing failed!\n";
        return 1;
    }

    std::cout << "\nNote: In real JSON files (500MB+), savings are much larger!\n";
    std::cout << "      Typical JSON has 80%+ string duplication.\n";

#else
    std::cout << "RapidJSON not available. This example requires RapidJSON.\n\n";
    std::cout << "To build with RapidJSON:\n";
    std::cout << "  1. Download from: https://github.com/Tencent/rapidjson\n";
    std::cout << "  2. Extract headers to include path\n";
    std::cout << "  3. Compile with: -DRAPIDJSON_AVAILABLE -I/path/to/rapidjson/include\n\n";

    // Show what the handler can do even without RapidJSON
    std::cout << "Handler Interface Preview:\n";
    std::cout << "  - Null(), Bool(), Int(), Uint(), Int64(), Uint64(), Double()\n";
    std::cout << "  - String(const char*, size_t, bool) - caches string\n";
    std::cout << "  - Key(const char*, size_t, bool) - caches object keys\n";
    std::cout << "  - StartObject(), EndObject(size_t)\n";
    std::cout << "  - StartArray(), EndArray(size_t)\n\n";

    std::cout << "Memory Benefits:\n";
    std::cout << "  - All string keys are cached (only one copy in memory)\n";
    std::cout << "  - All string values are cached\n";
    std::cout << "  - CachedString14 is only 8 bytes per reference\n";
    std::cout << "  - Typical savings: 60-70% for JSON with repeated strings\n";
#endif

    return 0;
}
