#include "string_cache_14.h"
#include <iostream>
#include <vector>

int main() {
    StringCache14 cache;

    // Intern some strings (including duplicates)
    std::vector<CachedString14> cached_strings;

    cached_strings.push_back(cache.intern("hello"));
    cached_strings.push_back(cache.intern("world"));
    cached_strings.push_back(cache.intern("hello"));  // Duplicate
    cached_strings.push_back(cache.intern("foo"));
    cached_strings.push_back(cache.intern("world"));  // Duplicate
    cached_strings.push_back(cache.intern("bar"));
    cached_strings.push_back(cache.intern("hello"));  // Duplicate

    std::cout << "Total cached strings added: " << cached_strings.size() << "\n";
    std::cout << "Unique strings in cache: " << cache.size() << "\n\n";

    // Resolve and print all cached strings
    std::cout << "Cached strings:\n";
    for (size_t i = 0; i < cached_strings.size(); ++i) {
        StringView sv = cache.resolve(cached_strings[i]);
        std::cout << "  [" << i << "] \"" << sv.to_string()
                  << "\" (id: " << cached_strings[i].index() << ")\n";
    }

    // Demonstrate that duplicate strings have the same ID
    std::cout << "\nDuplicate check:\n";
    auto hello1 = cache.intern("hello");
    auto hello2 = cache.intern("hello");
    std::cout << "  hello1 == hello2: " << (hello1 == hello2 ? "true" : "false") << "\n";
    std::cout << "  Both point to: \"" << cache.resolve(hello1).to_string() << "\"\n";

    // Memory efficiency demonstration
    std::cout << "\nMemory efficiency:\n";
    std::cout << "  Without caching: 7 strings × ~5 bytes = ~35 bytes\n";
    std::cout << "  With caching: 4 unique strings × ~5 bytes = ~20 bytes\n";
    std::cout << "  Plus 7 CachedString14 IDs × " << sizeof(CachedString14) << " bytes = "
              << (7 * sizeof(CachedString14)) << " bytes\n";

    // Test with std::string
    std::cout << "\nTesting with std::string:\n";
    std::string test_str = "C++14 compatible";
    auto cached_str = cache.intern(test_str);
    std::cout << "  Interned: \"" << cache.resolve(cached_str).to_string() << "\"\n";

    // Test with char* and length
    std::cout << "\nTesting with char* and length:\n";
    const char* raw_str = "Raw string test";
    auto cached_raw = cache.intern(raw_str, std::strlen(raw_str));
    std::cout << "  Interned: \"" << cache.resolve(cached_raw).to_string() << "\"\n";

    return 0;
}
