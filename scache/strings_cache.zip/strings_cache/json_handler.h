#pragma once

#include "string_cache_14.h"
#include <vector>
#include <memory>
#include <cstdint>

/**
 * JSONValue - Represents a parsed JSON value with cached strings.
 * Uses CachedString14 for all keys and string values to minimize memory.
 */
class JSONValue {
public:
    enum Type {
        TYPE_NULL,
        TYPE_BOOL,
        TYPE_INT64,
        TYPE_UINT64,
        TYPE_DOUBLE,
        TYPE_STRING,
        TYPE_ARRAY,
        TYPE_OBJECT
    };

    JSONValue() : type_(TYPE_NULL), int_value_(0) {}

    // Null
    static JSONValue makeNull() {
        return JSONValue();
    }

    // Bool
    static JSONValue makeBool(bool value) {
        JSONValue v;
        v.type_ = TYPE_BOOL;
        v.int_value_ = value ? 1 : 0;
        return v;
    }

    // Int64
    static JSONValue makeInt64(int64_t value) {
        JSONValue v;
        v.type_ = TYPE_INT64;
        v.int_value_ = value;
        return v;
    }

    // Uint64
    static JSONValue makeUint64(uint64_t value) {
        JSONValue v;
        v.type_ = TYPE_UINT64;
        v.uint_value_ = value;
        return v;
    }

    // Double
    static JSONValue makeDouble(double value) {
        JSONValue v;
        v.type_ = TYPE_DOUBLE;
        v.double_value_ = value;
        return v;
    }

    // String (cached)
    static JSONValue makeString(CachedString14 cached) {
        JSONValue v;
        v.type_ = TYPE_STRING;
        v.cached_string_ = cached;
        return v;
    }

    // Array
    static JSONValue makeArray() {
        JSONValue v;
        v.type_ = TYPE_ARRAY;
        v.array_ = std::make_shared<std::vector<JSONValue>>();
        return v;
    }

    // Object
    static JSONValue makeObject() {
        JSONValue v;
        v.type_ = TYPE_OBJECT;
        v.object_ = std::make_shared<std::vector<std::pair<CachedString14, JSONValue>>>();
        return v;
    }

    // Accessors
    Type type() const { return type_; }
    bool isNull() const { return type_ == TYPE_NULL; }
    bool isBool() const { return type_ == TYPE_BOOL; }
    bool isInt64() const { return type_ == TYPE_INT64; }
    bool isUint64() const { return type_ == TYPE_UINT64; }
    bool isDouble() const { return type_ == TYPE_DOUBLE; }
    bool isString() const { return type_ == TYPE_STRING; }
    bool isArray() const { return type_ == TYPE_ARRAY; }
    bool isObject() const { return type_ == TYPE_OBJECT; }

    // Getters
    bool getBool() const { return int_value_ != 0; }
    int64_t getInt64() const { return int_value_; }
    uint64_t getUint64() const { return uint_value_; }
    double getDouble() const { return double_value_; }
    CachedString14 getString() const { return cached_string_; }

    // Array operations
    void addArrayElement(JSONValue&& value) {
        if (array_) {
            array_->push_back(std::move(value));
        }
    }

    const std::vector<JSONValue>& getArray() const {
        static std::vector<JSONValue> empty;
        return array_ ? *array_ : empty;
    }

    // Object operations
    void addObjectMember(CachedString14 key, JSONValue&& value) {
        if (object_) {
            object_->push_back(std::make_pair(key, std::move(value)));
        }
    }

    const std::vector<std::pair<CachedString14, JSONValue>>& getObject() const {
        static std::vector<std::pair<CachedString14, JSONValue>> empty;
        return object_ ? *object_ : empty;
    }

private:
    Type type_;

    union {
        int64_t int_value_;
        uint64_t uint_value_;
        double double_value_;
        CachedString14 cached_string_;
    };

    std::shared_ptr<std::vector<JSONValue>> array_;
    std::shared_ptr<std::vector<std::pair<CachedString14, JSONValue>>> object_;
};

/**
 * CachedStringHandler - RapidJSON handler that caches all keys and string values.
 * Implements the RapidJSON Handler concept.
 */
class CachedStringHandler {
public:
    CachedStringHandler() : cache_(StringCache14::instance()) {
        // Start with a root value
        value_stack_.push_back(JSONValue::makeNull());
    }

    // Get the parsed result
    JSONValue getResult() {
        if (!value_stack_.empty()) {
            return std::move(value_stack_.back());
        }
        return JSONValue::makeNull();
    }

    // RapidJSON Handler interface
    bool Null() {
        addValue(JSONValue::makeNull());
        return true;
    }

    bool Bool(bool b) {
        addValue(JSONValue::makeBool(b));
        return true;
    }

    bool Int(int i) {
        addValue(JSONValue::makeInt64(i));
        return true;
    }

    bool Uint(unsigned u) {
        addValue(JSONValue::makeUint64(u));
        return true;
    }

    bool Int64(int64_t i) {
        addValue(JSONValue::makeInt64(i));
        return true;
    }

    bool Uint64(uint64_t u) {
        addValue(JSONValue::makeUint64(u));
        return true;
    }

    bool Double(double d) {
        addValue(JSONValue::makeDouble(d));
        return true;
    }

    bool String(const char* str, size_t length, bool /*copy*/) {
        // Intern the string into the cache
        CachedString14 cached = cache_.intern(str, length);
        addValue(JSONValue::makeString(cached));
        return true;
    }

    bool StartObject() {
        value_stack_.push_back(JSONValue::makeObject());
        return true;
    }

    bool Key(const char* str, size_t length, bool /*copy*/) {
        // Intern the key into the cache
        current_key_ = cache_.intern(str, length);
        return true;
    }

    bool EndObject(size_t /*memberCount*/) {
        if (value_stack_.size() > 1) {
            JSONValue obj = std::move(value_stack_.back());
            value_stack_.pop_back();
            addValue(std::move(obj));
        }
        return true;
    }

    bool StartArray() {
        value_stack_.push_back(JSONValue::makeArray());
        return true;
    }

    bool EndArray(size_t /*elementCount*/) {
        if (value_stack_.size() > 1) {
            JSONValue arr = std::move(value_stack_.back());
            value_stack_.pop_back();
            addValue(std::move(arr));
        }
        return true;
    }

    // Get cache statistics
    size_t getCacheSize() const {
        return cache_.size();
    }

private:
    void addValue(JSONValue&& value) {
        if (value_stack_.empty()) {
            value_stack_.push_back(std::move(value));
            return;
        }

        JSONValue& parent = value_stack_.back();

        if (parent.isObject()) {
            // Add as object member
            parent.addObjectMember(current_key_, std::move(value));
        } else if (parent.isArray()) {
            // Add as array element
            parent.addArrayElement(std::move(value));
        } else {
            // Replace root value
            value_stack_.back() = std::move(value);
        }
    }

    StringCache14& cache_;
    std::vector<JSONValue> value_stack_;
    CachedString14 current_key_;
};
