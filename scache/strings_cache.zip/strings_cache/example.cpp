#include "string_cache.h"
#include <iostream>
#include <vector>

int main() {
    StringCache cache;

    // Intern some strings (including duplicates)
    std::vector<CachedString> cached_strings;

    cached_strings.push_back(cache.intern("hello"));
    cached_strings.push_back(cache.intern("world"));
    cached_strings.push_back(cache.intern("hello"));  // Duplicate
    cached_strings.push_back(cache.intern("foo"));
    cached_strings.push_back(cache.intern("world"));  // Duplicate
    cached_strings.push_back(cache.intern("bar"));
    cached_strings.push_back(cache.intern("hello"));  // Duplicate

    std::cout << "Total cached strings added: " << cached_strings.size() << "\n";
    std::cout << "Unique strings in cache: " << cache.size() << "\n\n";

    // Resolve and print all cached strings
    std::cout << "Cached strings:\n";
    for (size_t i = 0; i < cached_strings.size(); ++i) {
        std::string_view str = cache.resolve(cached_strings[i]);
        std::cout << "  [" << i << "] \"" << str
                  << "\" (id: " << cached_strings[i].index() << ")\n";
    }

    // Demonstrate that duplicate strings have the same ID
    std::cout << "\nDuplicate check:\n";
    auto hello1 = cache.intern("hello");
    auto hello2 = cache.intern("hello");
    std::cout << "  hello1 == hello2: " << (hello1 == hello2 ? "true" : "false") << "\n";
    std::cout << "  Both point to: \"" << cache.resolve(hello1) << "\"\n";

    // Memory efficiency demonstration
    std::cout << "\nMemory efficiency:\n";
    std::cout << "  Without caching: 7 strings × ~5 bytes = ~35 bytes\n";
    std::cout << "  With caching: 4 unique strings × ~5 bytes = ~20 bytes\n";
    std::cout << "  Plus 7 CachedString IDs × " << sizeof(CachedString) << " bytes = "
              << (7 * sizeof(CachedString)) << " bytes\n";

    return 0;
}
